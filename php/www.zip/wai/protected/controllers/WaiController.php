<?php

class WaiController extends Controller
{
	public function filters()
	{
		return array(
			'accessControl',
		);
	}
	
	public function accessRules()
	{
		return array(
			array('allow',
				'users'=>array('*'),
			),
		);
	}
	
	public function __construct($id,$module=null)
	{
	    parent::__construct($id,$module);
		
		header("Content-type: text/html; charset=utf-8");
			
		$this->db = new CDbConnection('mysql:host=localhost;dbname=rsmy1', 'mhbox', 'comic413');
		$this->db->emulatePrepare = true;
		$this->db->charset = 'utf8';
		$this->db->active = true;
		
		/*
		 * 消息提示变量初始化
		 * */
		$this->message = CHtml::listData($this->db->createCommand(
			'select * from detail'
		)->query()->readAll(), 'code', 'show');
		return;
		
		/*
		 * 接口调用参数合法校验
		 * */
		if(!isset($_POST['time']) || empty($_POST['time']))
		{
			exit(CJSON::encode(array(
				'code'=>500,
				'detail'=>'没有检测到参数：time,或此参数为空',
			)));
		}
		
		/*
		 * 接口调用参数合法校验
		 * */
		if(!isset($_POST['token']) || empty($_POST['token']))
		{
			exit(CJSON::encode(array(
				'code'=>500,
				'detail'=>'没有检测到参数：token,或此参数为空',
			)));
		}
		
		/*
		 * 接口调用参数加密校验
		 * */
		if($_POST['token'] != md5($_POST['time'].$this->secretkey))
		{
			exit(CJSON::encode(array(
				'code'=>500,
				'detail'=>'检测到参数：token,被篡改',
			)));
		}
	}
	
	/*
	 * 焦点数据查询
	 * */
	public function actionMain()
	{
		if(isset($_POST))
		{
			if(!isset($_POST['main']) || empty($_POST['main']))
			{
				exit(CJSON::encode(array(
					'code'=>500,
					'detail'=>'没有检测到参数：main,或此参数为空',
				)));
			}
			
			if(isset($_POST['id']) && !empty($_POST['id']))
			{
				$this->condition = ' and sid = '.$_POST['id'];
			}
			
			$rest = $this->db->createCommand(
				'select * from page where main like \'%'.$_POST['main'].'%\''.$this->condition.' order by sort'
			)->query()->readAll();
			
			if(is_array($rest))
			{
				exit(CJSON::encode(array(
					'code'=>$this->status,
					'detail'=>$this->message[$this->status],
					'data'=>$rest,
				)));
			}
			
			exit(CJSON::encode(array(
				'code'=>500,
				'detail'=>'后台执行失败',
			)));
		}
	}
	
	/*
	 * 历史数据查询
	 * */
	public function actionList()
	{
		if(isset($_POST))
		{
			if(!isset($_POST['crp']) || empty($_POST['crp']))
			{
				exit(CJSON::encode(array(
					'code'=>500,
					'detail'=>'没有检测到参数：crp,或此参数为空',
				)));
			}
			
			if(isset($_POST['sid']) && !empty($_POST['sid']))
			{
				$this->condition = 'where sid like in ('.$_POST['sid'].')';
			}
			
			$rest = $this->db->createCommand(
				'select * from page '.$this->condition.' limit '.(($_POST['crp']  - 1) * 20).', 20'
			)->query()->readAll();
			
			if(is_array($rest))
			{
				exit(CJSON::encode(array(
					'code'=>$this->status,
					'detail'=>$this->message[$this->status],
					'data'=>$rest,
				)));
			}
			
			exit(CJSON::encode(array(
				'code'=>500,
				'detail'=>'后台执行失败',
			)));
		}
	}
	
	/*
	 * 封面数据查询
	 * */
	public function actionPage()
	{
		if(isset($_POST))
		{
			if(!isset($_POST['crp']) || empty($_POST['crp']))
			{
				exit(CJSON::encode(array(
					'code'=>500,
					'detail'=>'没有检测到参数：crp,或此参数为空',
				)));
			}
			
			if(isset($_POST['push']) && !empty($_POST['push']))
			{
				$this->condition = 'where push like \'%'.$_POST['push'].'%\' order by rank';
			}
			
			if(isset($_POST['title']) && !empty($_POST['title']))
			{
				$this->condition = 'where title like \'%'.$_POST['title'].'%\' or author like \'%'.$_POST['title'].'%\'';
			}
			
			$rest = $this->db->createCommand(
				'select * from page '.$this->condition.' limit '.(($_POST['crp']  - 1) * 20).', 20'
			)->query()->readAll();
			
			if(is_array($rest))
			{
				exit(CJSON::encode(array(
					'code'=>$this->status,
					'detail'=>$this->message[$this->status],
					'data'=>$rest,
				)));
			}
			
			exit(CJSON::encode(array(
				'code'=>500,
				'detail'=>'后台执行失败',
			)));
		}
	}

	/*
	 * 章节数据查询
	 * */
	public function actionRoll()
	{
		if(isset($_POST))
		{
			if(!isset($_POST['id']) || empty($_POST['id']))
			{
				exit(CJSON::encode(array(
					'code'=>500,
					'detail'=>'没有检测到参数：id,或此参数为空',
				)));
			}
			
			$rest = $this->db->createCommand(
				'select * from roll where pid = '.$_POST['id'].' order by id asc'
			)->query()->readAll();
			
			if(is_array($rest))
			{
				exit(CJSON::encode(array(
					'code'=>$this->status,
					'detail'=>$this->message[$this->status],
					'data'=>$rest,
				)));
			}
			
			exit(CJSON::encode(array(
				'code'=>500,
				'detail'=>'后台执行失败',
			)));
		}
	}

	/*
	 * 批次数据查询
	 * */
	public function actionSlap()
	{
		if(isset($_POST))
		{
			if(!isset($_POST['id']) || empty($_POST['id']))
			{
				exit(CJSON::encode(array(
					'code'=>500,
					'detail'=>'没有检测到参数：id,或此参数为空',
				)));
			}
			
			$rest = $this->db->createCommand(
				'select * from slap where rid = '.$_POST['id']
			)->query()->readAll();
			
			if(is_array($rest))
			{
				exit(CJSON::encode(array(
					'code'=>$this->status,
					'detail'=>$this->message[$this->status],
					'data'=>$rest,
				)));
			}
			
			exit(CJSON::encode(array(
				'code'=>500,
				'detail'=>'后台执行失败',
			)));
		}
	}
	
	/*
	 * 查询条件
	 * */
	private $db='';

	/*
	 * 查询条件
	 * */
	private $condition='';
	/*
	 * 返回状态码
	 * */
	private $status=200;
	/*
	 * 接口教研错误消息
	 * */
	private $message=array();
	/*
	 * 非传递密码，用来与请求参数一起加密，防止请求参数被篡改，以及接口的非法调用
	 * */
	private $secretkey='ada7d96dcb62d11432380caf9954590b';
}