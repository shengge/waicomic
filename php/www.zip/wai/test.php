<?php $date = date('Y-m-d H:i:s'); ?>
<html>
	<head>
		<title>adt face</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<style type="text/css">
			#app {
				overflow:hidden;
			}
			
			.post {
				margin:10px;
				float:left;
			}
		</style>
	</head>
	<body> 
		<div id="app">
				<div class="post">
					请求方式：POST
					<br />
					校验方式：md5(time.'ada7d96dcb62d11432380caf9954590b');
					<br />
					<br />
					参数列表：===========================================//
					<br />
					<br />
					&nbsp;&nbsp;&nbsp;&nbsp;id:漫画ID
					<br />
					&nbsp;&nbsp;main:漫画推荐
					<br />
					&nbsp;&nbsp;time:漫画创建时间
					<br />
					<br />
					参数列表：===========================================//
					<br />
					<br />
					接口地址：http://<?php echo $_SERVER['HTTP_HOST']; ?>/wai/main
					<form action="http://<?php echo $_SERVER['HTTP_HOST']; ?>/wai/main" method="post">
						<input type="text" name="id" value="" />漫画ID
						<br />
						<input type="text" name="main" value="" />漫画推荐
						<br />
						<input type="text" name="time" value="<?php echo $date; ?>" />漫画创建时间
						<br />
						<input type="hidden" name="token" value="<?php echo md5($date.'ada7d96dcb62d11432380caf9954590b'); ?>" />
						<input type="submit" value="提交" />
					</form>
				</div>
				<div class="post">
					请求方式：POST
					<br />
					校验方式：md5(time.'ada7d96dcb62d11432380caf9954590b');
					<br />
					<br />
					参数列表：===========================================//
					<br />
					<br />
					&nbsp;title:漫画名称或作者名称
					<br />
					&nbsp;&nbsp;push:漫画推荐
					<br />
					&nbsp;&nbsp;time:漫画创建时间
					<br />
					<br />
					参数列表：===========================================//
					<br />
					<br />
					接口地址：http://<?php echo $_SERVER['HTTP_HOST']; ?>/wai/page
					<form action="http://<?php echo $_SERVER['HTTP_HOST']; ?>/wai/page" method="post">
						<input type="text" name="title" value="" />漫画名称
						<br />
						<input type="text" name="push" value="" />漫画推荐
						<br />
						<input type="text" name="crp" value="" />漫画当前页
						<br />
						<input type="text" name="time" value="<?php echo $date; ?>" />漫画创建时间
						<br />
						<input type="hidden" name="token" value="<?php echo md5($date.'ada7d96dcb62d11432380caf9954590b'); ?>" />
						<input type="submit" value="提交" />
					</form>
				</div>
				<div class="post">
					请求方式：POST
					<br />
					校验方式：md5(time.'ada7d96dcb62d11432380caf9954590b');
					<br />
					<br />
					参数列表：===========================================//
					<br />
					<br />
					&nbsp;&nbsp;&nbsp;&nbsp;id:漫画ID
					<br />
					&nbsp;&nbsp;time:漫画创建时间
					<br />
					<br />
					参数列表：===========================================//
					<br />
					<br />
					接口地址：http://<?php echo $_SERVER['HTTP_HOST']; ?>/wai/roll
					<form action="http://<?php echo $_SERVER['HTTP_HOST']; ?>/wai/roll" method="post">
						<input type="text" name="id" value="" />漫画ID
						<br />
						<input type="text" name="time" value="<?php echo $date; ?>" />章节创建时间
						<br />
						<input type="hidden" name="token" value="<?php echo md5($date.'ada7d96dcb62d11432380caf9954590b'); ?>" />
						<input type="submit" value="提交" />
					</form>
				</div>
				<div class="post">
					请求方式：POST
					<br />
					校验方式：md5(time.'ada7d96dcb62d11432380caf9954590b');
					<br />
					<br />
					参数列表：===========================================//
					<br />
					<br />
					&nbsp;&nbsp;&nbsp;&nbsp;id:漫画ID
					<br />
					&nbsp;&nbsp;time:漫画创建时间
					<br />
					<br />
					参数列表：===========================================//
					<br />
					<br />
					接口地址：http://<?php echo $_SERVER['HTTP_HOST']; ?>/wai/slap
					<form action="http://<?php echo $_SERVER['HTTP_HOST']; ?>/wai/slap" method="post">
						<input type="text" name="id" value="" />章节ID
						<br />
						<input type="text" name="time" value="<?php echo $date; ?>" />批次创建时间
						<br />
						<input type="hidden" name="token" value="<?php echo md5($date.'ada7d96dcb62d11432380caf9954590b'); ?>" />
						<input type="submit" value="提交" />
					</form>
				</div>
			</div>
	</body>
<html>